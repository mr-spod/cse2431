/*
shellA.h
Author: Sean O'Donnell

Exposes method to execute command in shell
*/

void executeShellCommand(char *args[], int *isHistory, int *isR, int *historyIndex, int commandCount);
