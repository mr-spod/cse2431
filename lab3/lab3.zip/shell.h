/*
shellA.h
Author: Sean O'Donnell

Exposes 10-element buffer of commands
*/

#define MAXLINE 80
extern char commandHistory[10][MAXLINE/2+1];
