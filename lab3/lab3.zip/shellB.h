/*
shellA.h
Author: Sean O'Donnell

Exposes methods to read/write command history
*/

void readHistory(int *cmdCount);

void writeHistory(int cmdCount);
